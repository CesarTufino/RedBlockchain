package logicaDistribuida4.test;

import java.io.IOException;
import java.security.KeyPair;
import java.util.Scanner;

import logicaDistribuida4.conexion.Entrada;
import logicaDistribuida4.nodo.*;
import logicaDistribuida4.utils.RsaUtil;

public class TestNodo1 {

    public static void main(String[] args) throws IOException {

        int puertoRecepcion = 12346;

        KeyPair keys = null;
        try {
            keys = RsaUtil.generateKeyPair();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Mi nodo
        // La dirección en "logica" se obtiene de un hash a la clave publica
        Nodo nodo = new Nodo(1, "192.168.100.73", keys);
        // Poner el stake
        nodo.stake(20, "Type1");
        nodo.stake(10, "Type2");

        // Hilo para escuchar
        Entrada hiloEntrada = new Entrada(nodo, puertoRecepcion);
        hiloEntrada.start();

        // Buscar datos en la red
        nodo.buscarInfoRed();

        // Hilo para validación PoS
        Validador hiloValidador = new Validador(nodo.getInfoRed(), nodo);
        hiloValidador.start();

        Scanner sc = new Scanner(System.in);
        sc.nextLine();


        for (int i = 0; i < 2; i++) {
            if (i==0)
                nodo.sendMoneyTo(1.23, "192.168.100.9", "Type1");
            else
                nodo.sendMoneyTo(3.47, "192.168.100.9", "Type1");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }

        sc.nextLine();

        nodo.getInfoRed().getBlockchain().printBlk();

        sc.close();
    }
}
