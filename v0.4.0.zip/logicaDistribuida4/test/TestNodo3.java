package logicaDistribuida4.test;

import java.io.IOException;
import java.security.KeyPair;
import java.util.Scanner;

import logicaDistribuida4.conexion.Entrada;
import logicaDistribuida4.nodo.Nodo;
import logicaDistribuida4.nodo.Validador;
import logicaDistribuida4.utils.RsaUtil;

public class TestNodo3 {

    public static void main(String[] args) throws IOException {
        // A donde se va a enviar
        int puertoRecepcion = 12343;

        KeyPair keys = null;
        try {
            keys = RsaUtil.generateKeyPair();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Mi nodo
        Nodo nodo = new Nodo(3, "192.168.100.9", keys);
        // Poner el stake
        nodo.stake(5, "Type1");
        nodo.stake(10, "Type2");

        // Hilo para escuchar
        Entrada serverThread = new Entrada(nodo, puertoRecepcion);
        serverThread.start();

        // Buscar datos en la red
        nodo.buscarInfoRed();

        // Hilo para validación PoS
        Validador hiloValidador = new Validador(nodo.getInfoRed(), nodo);
        hiloValidador.start();

        Scanner sc = new Scanner(System.in);
        sc.nextLine();
        sc.close();

        nodo.sendMoneyTo(1.23, "192.168.100.73", "Type1");
    }
}
