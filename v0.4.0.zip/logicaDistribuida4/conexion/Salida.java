package logicaDistribuida4.conexion;

import java.io.*;
import java.net.*;
import java.security.PublicKey;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import logicaDistribuida4.nodo.InfoRed;
import logicaDistribuida4.nodo.Nodo;
import logicaDistribuida4.blockchain.Block;
import logicaDistribuida4.mensajes.InfoNodo;
import logicaDistribuida4.mensajes.Mensaje;
import logicaDistribuida4.mensajes.Transaccion;

public class Salida {
    private Nodo miNodo;
    private String host;
    private int puertoEnvio;
    private HashMap<String, Integer> direcciones = new HashMap<>();

    public Salida(Nodo miNodo) {
        this.miNodo = miNodo;
        /* Nodo 1 */
        direcciones.put("192.168.100.73", 12346);
        /* Nodo 3 */
        direcciones.put("192.168.100.9", 12343);
    }

    public void broadcastMessage(Mensaje m) {
        System.out.println("Broadcasting Message");
        direcciones.forEach((d, p) -> enviarMensaje(d, p, m));
        if (m.getType() == 1) {
            Block block;
            try {
                block = (Block) m.getMessageContent().get(0);
                if (!block.getNodeAddress().equals("Master"))
                    updateAllWallet(block);
            } catch (NullPointerException ignored) {
            }
        }
    }

    private void enviarMensaje(String d, Integer p, Mensaje m) {
        this.host = d;
        this.puertoEnvio = p;
        Socket socket;
        System.out.println("Envio de Mensaje a " + host);
        if (!miNodo.getNodeAddress().equals(host)) {
            try {
                socket = new Socket();
                socket.bind(null);
                InetSocketAddress isa = new InetSocketAddress(host, puertoEnvio);
                socket.connect(isa, 1000);
                System.out.println("Conexion iniciada");
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                out.writeObject(m);
            } catch (IOException e) {
                System.out.println("-------------------");
                System.out.println("No se pudo establecer conexión con " + host);
                System.out.println("-------------------");
                // e.printStackTrace();
            }
        } else {
            System.out.println("Nodo local");
            miNodo.receiptMessage(m);
        }
    }

    /**
     * Método que actualiza las billeteras de todos los nodos que participaron.
     *
     * @param b Bloque.
     */
    private void updateAllWallet(Block b) {
        double totalFee = 0;
        List<Transaccion> t = b.getTransaction();
        double montoTotal = 0;
        for (Transaccion transaction : t) {
            transaction.confirmed();
            double montoTransaccion = transaction.getAmount();
            double tarifaTransaccion = transaction.getTransactionFee();
            double takenFromTrans = tarifaTransaccion * montoTransaccion;
            String toAddress = transaction.getToAddress();
            montoTotal += montoTransaccion;
            totalFee += takenFromTrans;
            // Actualización de la billetera del destinatario de la transacción.
            updateWalletWithAddress(montoTransaccion, toAddress, transaction.getTransactionID());
            // Actualización de la billetera del emisor de la transacción.
            updateWalletWithAddress(-(montoTransaccion + takenFromTrans), transaction.getFromAddress(),
                    transaction.getTransactionID());
        }

        // Los intercambios de dinero se agregan a la lista de la red.
        if (b.getBlockID().equals("Type1")) {
            broadcastExchangeMoneyAdd(1, montoTotal);
            broadcastExchangeMoneyAdd(2, 0);
        }
        if (b.getBlockID().equals("Type2")) {
            broadcastExchangeMoneyAdd(2, montoTotal);
            broadcastExchangeMoneyAdd(1, 0);
        }

        // Actualización del minero.
        updateWalletWithAddress(totalFee, b.getNodeAddress(), b.getBlockID());
    }

    /**
     * Método para actualizar la billetera del cliente con su dirección.
     *
     * @param amount        Monto de la transacción.
     * @param clientAddress Dirección del beneficiario.
     * @param type          Identificador de la transacción.
     */
    public void updateWalletWithAddress(double amount, String clientAddress, String type) {
        this.host = clientAddress;
        this.puertoEnvio = direcciones.get(clientAddress);
        Socket socket;
        System.out.println("Envio de peticion (actualización de billetera) a " + host);
        if (!miNodo.getNodeAddress().equals(host)) {
            try {
                socket = new Socket();
                socket.bind(null);
                InetSocketAddress isa = new InetSocketAddress(host, puertoEnvio);
                socket.connect(isa, 1000);
                System.out.println("Conexion iniciada");
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                if (type.equals("Type1")) {
                    out.writeObject("ActBilleteraType1" + amount);
                } else {
                    out.writeObject("ActBilleteraType2" + amount);
                }
            } catch (IOException e) {
                System.out.println("-------------------");
                System.out.println("No se pudo establecer conexión con " + host);
                System.out.println("-------------------");
            }
        } else {
            System.out.println("Nodo local");
            miNodo.receiptCoin(amount, type);
        }
    }

    public void buscarInfoRed() {
        pedirInfoRed();
        if (miNodo.getInfoRed() == null) {
            System.out.println("No se pudo copiar un InfoRed");
            miNodo.setInfoRed(new InfoRed());
        } else {
            System.out.println("Copia de InfoRed creada");
        }
        broadcastInfoNodo(miNodo.getNodeAddress(), miNodo.getPublicKey(), miNodo.getStakeAmount1(),
                miNodo.getStakeAmount2(), miNodo.getStakeTime());
    }

    private void broadcastInfoNodo(String nodeAddress, PublicKey publicKey, double stakeAmount1, double stakeAmount2,
            long stakeTime) {
        direcciones
                .forEach((d, p) -> enviarInfoNodo(d, p, nodeAddress, publicKey, stakeAmount1, stakeAmount2, stakeTime));
    }

    private void enviarInfoNodo(String d, Integer p, String nodeAddress, PublicKey publicKey, double stakeAmount1,
            double stakeAmount2, long stakeTime) {
        this.host = d;
        this.puertoEnvio = p;
        Socket socket;
        InfoNodo clavePublica = new InfoNodo(nodeAddress, publicKey, stakeAmount1, stakeAmount2, stakeTime);
        System.out.println("Envio de información del nodo a " + host);
        if (!miNodo.getNodeAddress().equals(host)) {
            try {
                socket = new Socket();
                socket.bind(null);
                InetSocketAddress isa = new InetSocketAddress(host, puertoEnvio);
                socket.connect(isa, 1000);
                System.out.println("Conexion iniciada");
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                out.writeObject(clavePublica);
            } catch (IOException e) {
                System.out.println("-------------------");
                System.out.println("No se pudo establecer conexión con " + host);
                System.out.println("-------------------");
            }
        } else {
            System.out.println("Nodo local");
            InfoRed infoRed = miNodo.getInfoRed();
            infoRed.addNode(nodeAddress, publicKey, stakeAmount1, stakeAmount2, stakeTime);
        }
    }

    private void pedirInfoRed() {
        Set<String> listaDirecciones = direcciones.keySet();
        for (String direccion : listaDirecciones) {
            if (miNodo.getInfoRed() == null) {
                this.host = direccion;
                this.puertoEnvio = direcciones.get(direccion);
                Socket socket = new Socket();
                System.out.println("Envío de peticion (Pedir copia de InfoRed) a " + host);
                if (!miNodo.getNodeAddress().equals(host)) {
                    try {
                        socket.bind(null);
                        InetSocketAddress isa = new InetSocketAddress(host, puertoEnvio);
                        socket.connect(isa, 1000);
                        System.out.println("Conexion iniciada");
                        ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                        out.writeObject("InfoRed" + miNodo.getNodeAddress());
                        socket.close();
                    } catch (IOException e) {
                        System.out.println("-------------------");
                        System.out.println("No se pudo establecer conexión con " + host);
                        System.out.println("-------------------");
                    }
                } else {
                    System.out.println("Nodo local");
                    continue;
                }
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                
            } else {
                break;
            }
        }
        
    }

    public void enviarInfoRed(InfoRed infoRed, String direccion) {
        this.host = direccion;
        this.puertoEnvio = direcciones.get(direccion);
        Socket socket;
        System.out.println("Envio de copia InfoRed a " + host);
        if (!miNodo.getNodeAddress().equals(host)) {
            try {
                socket = new Socket();
                socket.bind(null);
                InetSocketAddress isa = new InetSocketAddress(host, puertoEnvio);
                socket.connect(isa, 1000);
                System.out.println("Conexion iniciada");
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                out.writeObject(infoRed);
            } catch (IOException e) {
                System.out.println("-------------------");
                System.out.println("No se pudo establecer conexión con " + host);
                System.out.println("-------------------");
            }
        } else {
            System.out.println("Nodo local");
        }
    }

    public void broadcastNbTransParType(String transactionType, int cantidad) {
        System.out.println("Broadcast actualizacion NbTransParType");
        direcciones.forEach((d, p) -> enviarActualizacionNbTransParType(d, p, transactionType, cantidad));
    }

    private void enviarActualizacionNbTransParType(String d, Integer p, String transactionType, int cantidad) {
        this.host = d;
        this.puertoEnvio = p;
        Socket socket;
        System.out.println("Envío de petición (Actualización NbTransParType) a " + host);
        if (!miNodo.getNodeAddress().equals(host)) {
            try {
                socket = new Socket();
                socket.bind(null);
                InetSocketAddress isa = new InetSocketAddress(host, puertoEnvio);
                socket.connect(isa, 1000);
                System.out.println("Conexion iniciada");
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                if (transactionType.equals("Type1")) {
                    if (cantidad == 1) {
                        out.writeObject("NbTransParType1+");
                    } else {
                        out.writeObject("NbTransParType1-");
                    }
                } else {
                    if (cantidad == -1) {
                        out.writeObject("NbTransParType2+");
                    } else {
                        out.writeObject("NbTransParType2-");
                    }
                }
            } catch (IOException e) {
                System.out.println("-------------------");
                System.out.println("No se pudo establecer conexión con " + host);
                System.out.println("-------------------");
            }
        } else {
            System.out.println("Nodo local");
            miNodo.actualizarNbTransParType(transactionType, cantidad);
        }
    }

    public void broadcastST(double st) {
        System.out.println("Broadcast actualizacion NbTransParType");
        direcciones.forEach((d, p) -> enviarActualizacionST(d, p, st));
    }

    private void enviarActualizacionST(String d, Integer p, double st) {
        this.host = d;
        this.puertoEnvio = p;
        Socket socket;
        System.out.println("Envío de petición (Actualización ST) a " + host);
        if (!miNodo.getNodeAddress().equals(host)) {
            try {
                socket = new Socket();
                socket.bind(null);
                InetSocketAddress isa = new InetSocketAddress(host, puertoEnvio);
                socket.connect(isa, 1000);
                System.out.println("Conexion iniciada");
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                out.writeObject("ActualizaST" + st);
            } catch (IOException e) {
                System.out.println("-------------------");
                System.out.println("No se pudo establecer conexión con " + host);
                System.out.println("-------------------");
            }
        } else {
            System.out.println("Nodo local");
            miNodo.actualizarST(st);
        }
    }

    public void broadcastNBOfBlockOfTypeAdd(String type) {
        System.out.println("Broadcast actualizacion NBOfBlockOfType");
        direcciones.forEach((d, p) -> enviarActualizacionNBOfBlockOfTypeAdd(d, p, type));
    }

    private void enviarActualizacionNBOfBlockOfTypeAdd(String d, Integer p, String type) {
        this.host = d;
        this.puertoEnvio = p;
        Socket socket;
        System.out.println("Envío de petición (Actualización NBOfBlockOfTypeAdd) a " + host);
        if (!miNodo.getNodeAddress().equals(host)) {
            try {
                socket = new Socket();
                socket.bind(null);
                InetSocketAddress isa = new InetSocketAddress(host, puertoEnvio);
                socket.connect(isa, 1000);
                System.out.println("Conexion iniciada");
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                if (type == "Type1") {
                    out.writeObject("ActualizaNBOfBlockOfType1Add");
                } else {
                    out.writeObject("ActualizaNBOfBlockOfType2Add");
                }
            } catch (IOException e) {
                System.out.println("-------------------");
                System.out.println("No se pudo establecer conexión con " + host);
                System.out.println("-------------------");
            }
        } else {
            System.out.println("Nodo local");
            miNodo.actualizarNBOfBlockOfTypeAdd(type);
        }
    }

    private void broadcastExchangeMoneyAdd(int iType, double amount) {
        System.out.println("Broadcast actualizacion ExchangeMoney");
        direcciones.forEach((d, p) -> enviarActualizacionExchangeMoneyAdd(d, p, iType, amount));
    }

    private void enviarActualizacionExchangeMoneyAdd(String d, Integer p, int iType, double amount) {
        this.host = d;
        this.puertoEnvio = p;
        Socket socket;
        System.out.println("Envío de petición (Actualización ExchangeMoneyAdd) a " + host);
        if (!miNodo.getNodeAddress().equals(host)) {
            try {
                socket = new Socket();
                socket.bind(null);
                InetSocketAddress isa = new InetSocketAddress(host, puertoEnvio);
                socket.connect(isa, 1000);
                System.out.println("Conexion iniciada");
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                if (iType == 1) {
                    out.writeObject("ActualizaExchangeMoneyAdd1" + amount);
                } else {
                    out.writeObject("ActualizaExchangeMoneyAdd2" + amount);
                }
            } catch (IOException e) {
                System.out.println("-------------------");
                System.out.println("No se pudo establecer conexión con " + host);
                System.out.println("-------------------");
            }
        } else {
            System.out.println("Nodo local");
            miNodo.actualizarExchangeMoneyAdd(iType, amount);
        }
    }

}
