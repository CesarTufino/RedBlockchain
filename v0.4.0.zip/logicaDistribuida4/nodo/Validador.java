package logicaDistribuida4.nodo;

public class Validador extends Thread {

    private InfoRed infoRed = null;
    private Nodo miNodo = null;

    public Validador(InfoRed infoRed, Nodo miNodo) {
        this.infoRed = infoRed;
        this.miNodo = miNodo;
    }

    public void validar() {
        while (true) {
            String[] seleccionados = determinarSeleccionadosPoS();

            if (seleccionados[0].equals(miNodo.getNodeAddress())) {
                System.out.println("/////////////// Se crea el Bloque Tipo 1 ////////////");
                miNodo.forgeBlock("Type1");
            }

            if (seleccionados[1].equals(miNodo.getNodeAddress())) {
                // System.out.println("/////////////// Se crea el Bloque Tipo 2 ////////////");
                // miNodo.forgeBlock("Type2");
            }

            long start = System.currentTimeMillis();
            while (true) {
                long end = System.currentTimeMillis();
                if (end - start > 10000) { // 10 segundos
                    break;
                }
            }
            break;
        }
    }

    private String[] determinarSeleccionadosPoS() {
        System.out.println("/////////////// Seleccionando nodos //////////");
        // String[] seleccionados = { "192.168.100.73", "192.168.100.9"};
        String[] seleccionados = new String[2];
        seleccionados[0] = infoRed.getMasprobable("Type1");
        seleccionados[1] = infoRed.getMasprobable("Type2");
        return seleccionados;
    }

    @Override
    public void run() {
        long tiempoParaIniciar = 10000 - infoRed.getTiempoTranscurrido() % 10000;
        System.out.println();
        try {
            Thread.sleep(tiempoParaIniciar);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        validar();
    }

}
