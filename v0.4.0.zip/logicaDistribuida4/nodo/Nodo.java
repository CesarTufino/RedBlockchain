package logicaDistribuida4.nodo;

import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import logicaDistribuida4.utils.HashUtil;
import logicaDistribuida4.blockchain.Blockchain;
import logicaDistribuida4.conexion.Salida;
import logicaDistribuida4.mensajes.Mensaje;
import logicaDistribuida4.mensajes.Transaccion;
import logicaDistribuida4.blockchain.Block;
import logicaDistribuida4.utils.RsaUtil;

public class Nodo {

    private Salida salida;

    /* Nodo */
    /**
     * Clave publica del nodo. (Identificador del segundo nodo, utilizado para
     * verificar las firmas)
     */
    public PublicKey publicKey;
    /**
     * Clave privada del nodo. (Actúa como su contraseña, necesaria para firmar la
     * transacción)
     */
    public PrivateKey privateKey;
    /**
     * Dirección del nodo.
     */
    protected String nodeAddress;
    /**
     * Identificador del nodo.
     */
    protected final int nodeID;
    /**
     * Nombre del nodo.
     */
    public String name;

    /**
     * Tarifa de transacción que se aplica cuando un LightNode envía dinero a otro
     * LightNode
     */
    public final static double TRANSACTION_FEE = 0.1;
    /**
     * Valor inicial en la wallet.
     */
    public final static int INIT_WALLET = 100000000;
    /**
     * Wallet para el primer blockchain lógico.
     */
    public double wallet1;
    /**
     * Wallet para el segundo blockchain lógico.
     */
    public double wallet2;
    /**
     * Monto de apuesta para el primer blockchain lógico.
     */
    public double stakeAmount1;
    /**
     * Monto de apuesta para el segundo blockchain lógico.
     */
    public double stakeAmount2;
    /**
     * Fecha de la última apuesta.
     */
    public long stakeTime;

    /* Validator Node */
    /**
     * Cantidad máxima de las transacciones en un bloque.
     */
    public static int MAX_TRANSACTION = 2; // 10
    /**
     * Tasa de inversión.
     */
    public static double INVEST_RATE = 0.80;
    /**
     * Lista de trasacciones pendientes.
     */
    private final ArrayList<Transaccion> pendingTransaction = new ArrayList<>();
    /**
     * Lista de trasacciones fraudulentas.
     */
    private final ArrayList<Transaccion> fraudulentTransaction = new ArrayList<>();

    private InfoRed infoRed = null;

    public Nodo(int id, String nodeAddress, KeyPair keys) {
        this.nodeID = id;
        this.publicKey = keys.getPublic();
        this.privateKey = keys.getPrivate();
        // this.nodeAddress = HashUtil.SHA256(String.valueOf(publicKey));
        this.nodeAddress = nodeAddress;
        this.wallet1 = INIT_WALLET;
        this.wallet2 = INIT_WALLET;
        this.stakeAmount1 = 0;
        this.stakeAmount2 = 0;
        this.stakeTime = System.currentTimeMillis();
        this.salida = new Salida(this);
        this.name = Integer.toString(id);
    }

    public void buscarInfoRed() {
        salida.buscarInfoRed();
    }

    public void sendMoneyTo(double amount, String nodeAddress, String transactionType) {
        System.out.println("Inicio de transacción");
        if (transactionType.equals("Type1")) {
            if (wallet1 - amount * (1 + TRANSACTION_FEE) < 0) {
                System.out.println(name + " Not enough currency of type " + transactionType + " to send");
                System.out.println("Rejected transaction");
                return;
            }
        } else {
            if (wallet2 - amount * (1 + TRANSACTION_FEE) < 0) {
                System.out.println(name + " Not enough currency of type " + transactionType + " to send");
                System.out.println("Rejected transaction");
                return;
            }
        }
        Transaccion toSend = new Transaccion(transactionType, this.getNodeAddress(), nodeAddress, amount,
                System.currentTimeMillis(), TRANSACTION_FEE, privateKey);
        Mensaje m = null;
        try {
            m = new Mensaje(this.nodeAddress, nodeAddress, RsaUtil.sign(toSend.toString(), privateKey),
                    System.currentTimeMillis(), 0, toSend);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Mensaje creado");
        salida.broadcastMessage(m);
        // contar el número de transacciones por tipo
        salida.broadcastNbTransParType(transactionType, 1);
    }

    public void receiptCoin(double amount, String type) {
        System.out.println("Cantidad recibida: " + amount);
        if (type == "Type1") {
            wallet1 += amount;
            System.out.println("Nuevo valor: " + wallet1);
        } else {
            wallet2 += amount;
            System.out.println("Nuevo valor: " + wallet2);
        }
    }

    public void receiptMessage(Mensaje message) {
        int messageType = message.getType();
        List<Object> listOfContent = message.getMessageContent();
        if (messageType == 0) {
            Transaccion tr = (Transaccion) (listOfContent.get(0));
            System.out.println("Transaccion recibida");
            receiptTransaction(tr);
        }
        if (messageType == 1) {
            Block bPrev = (Block) listOfContent.get(0);
            String nodeAddress = message.getFromAddress();
            String signature = message.getSignature();
            System.out.println("Bloque recibido");
            receiptBlock(bPrev, signature, nodeAddress);
        }
    }

    public void receiptTransaction(Transaccion t) {
        boolean transactionStatus = false;
        try {
            transactionStatus = verifyTransaction(t);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (transactionStatus) {
            pendingTransaction.add(t);
            System.out.println("\n///-----------------------------------///");
            System.out.println("Información de la transacción recibida:");
            System.out.println(t);
            System.out.println("///-----------------------------------///\n");
        } else {
            fraudulentTransaction.add(t);
        }
    }

    public boolean verifyTransaction(Transaccion t) throws Exception {
        return RsaUtil.verify(t.toString(), t.getSignature(), infoRed.getPkWithAddress(t.getFromAddress()));
    }

    public void receiptBlock(Block b, String signature, String nodeAddress) {
        updateTransactionList(b);
        try {
            if (RsaUtil.verify(HashUtil.SHA256(b.toString()), signature, infoRed.getPkWithAddress(nodeAddress))) {
                infoRed.addBlock(b);
                System.out.println("\n///-----------------------------------///");
                System.out.println("Información del bloque recibido:");
                System.out.println(b);
                System.out.println(b.getTransaction());
                System.out.println("///-----------------------------------///\n");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateTransactionList(Block b) {
        List<Transaccion> lt = b.getTransaction();
        for (Transaccion t : lt) {
            pendingTransaction.remove(t);
        }
    }

    public void forgeBlock(String type) {
        System.out.println();
        System.out.println("---------------------------------------------------");
        List<Transaccion> inBlockTransaction = new ArrayList<>();
        for (int i = 0; (i < MAX_TRANSACTION) && (i < pendingTransaction.size()); i++) {
            if (pendingTransaction.get(i).getTransactionID().equals(type)) {
                inBlockTransaction.add(pendingTransaction.get(i));
                System.out.println(pendingTransaction.get(i).getTransactionID());
                salida.broadcastNbTransParType(type, -1);
            }
        }
        long start = System.nanoTime();
        Blockchain blockchain = infoRed.getBlockchain();
        Block prevBlockID = blockchain.searchPrevBlockByID(type, blockchain.getSize() - 1);
        long end = System.nanoTime();
        salida.broadcastST((double) end - start);
        Block forgedBlock = new Block(blockchain.getLatestBlock(), prevBlockID, inBlockTransaction, type);
        forgedBlock.setNodeID(this.nodeID);
        forgedBlock.setNodeAddress(this.nodeAddress);
        System.out.println("Block has been forged by " + this.name);
        try {
            List<Object> messageContent = new ArrayList<>();
            messageContent.add(forgedBlock);
            //messageContent.add(blockchain);
            Mensaje m = new Mensaje(this.nodeAddress, "ALL",
                    RsaUtil.sign(HashUtil.SHA256(forgedBlock.toString()), this.privateKey), System.currentTimeMillis(),
                    1, messageContent);
            salida.broadcastMessage(m);
            if (type.equals("Type1")) {
                salida.broadcastNBOfBlockOfTypeAdd(type);

            } else {
                salida.broadcastNBOfBlockOfTypeAdd(type);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error signing");
        }
        System.out.println("---------------------------------------------------");
        
    }

    public void stake(int amount, String type) {
        if (type.equals("Type1")) {
            if (wallet1 < amount) {
                System.out.println(name + " don't have enough money for stake in wallet1");
            }
            stakeAmount1 = amount;
            this.wallet1 -= amount;
        } else {
            if (wallet2 < amount) {
                System.out.println(name + " don't have enough money for stake in wallet2");
            }
            stakeAmount2 = amount;
            this.wallet2 -= amount;
        }
        stakeTime = System.currentTimeMillis();
        System.out.println(name + " deposit " + amount + " as stake for " + type);
        System.out.println();
    }

    public void enviarInfoRed(String direccion) {
        infoRed.actualizarTiempoTranscurrido();
        salida.enviarInfoRed(infoRed, direccion);
    }

    public void actualizarNbTransParType(String transactionType, int cantidad) {
        HashMap<String, Integer> nbTransParType = (HashMap<String, Integer>) infoRed.getNbTransParType();
        infoRed.setNbTransParType(transactionType, nbTransParType.get(transactionType) + cantidad);
    }

    public void actualizarST(double st) {
        infoRed.ST.add(st);
    }

    public void actualizarNBOfBlockOfTypeAdd(String type) {
        if (type == "Type1") {
            infoRed.NB_OF_BLOCK_OF_TYPE1_CREATED.add(infoRed.NB_OF_BLOCK_OF_TYPE1_CREATED.size() + 1);
        } else {
            infoRed.NB_OF_BLOCK_OF_TYPE2_CREATED.add(infoRed.NB_OF_BLOCK_OF_TYPE2_CREATED.size() + 1);
        }
        // Último en ejecutarse
        infoRed.printStats();
    }

    public void actualizarExchangeMoneyAdd(int iType, double amount) {
        if (iType == 1) {
            infoRed.EXCHANGE_MONEY1.add(infoRed.EXCHANGE_MONEY1.get(infoRed.EXCHANGE_MONEY1.size() - 1) + amount);
            infoRed.EXCHANGE_MONEY2.add(infoRed.EXCHANGE_MONEY2.get(infoRed.EXCHANGE_MONEY2.size() - 1));
        } else {
            infoRed.EXCHANGE_MONEY2.add(infoRed.EXCHANGE_MONEY2.get(infoRed.EXCHANGE_MONEY2.size() - 1) + amount);
            infoRed.EXCHANGE_MONEY1.add(infoRed.EXCHANGE_MONEY1.get(infoRed.EXCHANGE_MONEY1.size() - 1));
        }

    }

    public PublicKey getPublicKey() {
        return publicKey;
    }

    public double getStakeAmount1() {
        return stakeAmount1;
    }

    public double getStakeAmount2() {
        return stakeAmount2;
    }


    public long getStakeTime() {
        return stakeTime;
    }


    public String getNodeAddress() {
        return nodeAddress;
    }

    public InfoRed getInfoRed() {
        return infoRed;
    }

    public void setInfoRed(InfoRed infoRed) {
        this.infoRed = infoRed;
    }

}
