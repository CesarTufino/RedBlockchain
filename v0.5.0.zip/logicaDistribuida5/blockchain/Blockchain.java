package logicaDistribuida5.blockchain;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class Blockchain  implements Serializable{

    /**
     * Lista de los Bloques.
     */
    private final List<Block> blkchain = new CopyOnWriteArrayList<>();
    /**
     * Diferencia de tiempo de creación entre los bloques del primer blockchain
     * lógico.
     */
    public final List<Double> WTT1 = new CopyOnWriteArrayList<>();
    /**
     * Diferencia de tiempo de creación entre los bloques del segundo blockchain
     * lógico.
     */
    public final List<Double> WTT2 = new CopyOnWriteArrayList<>();

    /**
     * Constructor del Blockchain.
     * Crea un Blockchain, de le asigna un id y se crean los primeros bloques.
     * 
     * @param network Representación de la red.
     */
    public Blockchain() {
        this.blkchain.addAll(createFirstBlock());
    }

    /**
     * Método que crea el primer bloque de cada blockchain lógico.
     *
     * @return Primeros bloques.
     */
    public List<Block> createFirstBlock() {
        Block firstBlock = new Block("Type1"); // network.TYPE1
        Block secondBlock = new Block(firstBlock, "Type2");
        return Arrays.asList(firstBlock, secondBlock);
    }

    /**
     * Método que devuelve el último bloque del blockchain físico.
     *
     * @return Último bloque del blockchain físico.
     */
    public Block getLatestBlock() {
        return blkchain.get(blkchain.size() - 1);
    }

    /**
     * Método que devuelve el último bloque de un blockchain lógico.
     *
     * @param blockID Identificador del blockchain lógico.
     * @param i       Posición desde la que se comienza a buscar.
     * @return Último bloque del blockchain lógico.
     */
    public Block searchPrevBlockByID(String blockID, int i) {
        if (i < 0) {
            return null;
        }
        Block b = this.blkchain.get(i);
        if (blockID.equals(b.getBlockID()))
            return b;
        else {
            return searchPrevBlockByID(blockID, --i);
        }
    }

    /**
     * Método que agrega un bloque al blockchain físico y
     * guarda la diferencia de tiempo de creación entre el bloque actual y el
     * anterior.
     *
     * @param block Bloque que se va a añadir.
     */
    public synchronized void addBlock(Block block) {
        String ID = block.getBlockID();
        Block prevBlock = searchPrevBlockByID(ID, this.blkchain.size() - 1);
        if (ID.equals("Type1")) {
            WTT1.add((double) (block.getHeader().getTimeStamp() - prevBlock.getHeader().getTimeStamp()) / 1000);
            WTT2.add((double) 0);
        } else {
            WTT2.add((double) (block.getHeader().getTimeStamp() - prevBlock.getHeader().getTimeStamp()) / 1000);
            WTT1.add((double) 0);
        }
        blkchain.add(block);
    }

    /**
     * Método que imprime la información de todos los bloques.
     */
    public void printBlk() {
        for (Block block : blkchain) {
            System.out.println("\n//////////////////Blockchain///////////////////");
            System.out.println(block.toString());
            System.out.println("//////////////////Blockchain///////////////////\n");
        }
    }

    /**
     * Método que devuelve el tamaño del blockchain físico.
     *
     * @return Tamaño del blockchain físico.
     */
    public int getSize() {
        return blkchain.size();
    }

    public List<Double> getWTT1() {
        return WTT1;
    }

    public List<Double> getWTT2() {
        return WTT2;
    }

}
