package logicaDistribuida5.test;

import java.io.IOException;
import java.security.KeyPair;
import java.util.Scanner;

import logicaDistribuida5.conexion.Entrada;
import logicaDistribuida5.nodo.*;
import logicaDistribuida5.utils.RsaUtil;

public class TestTipo3Nodo1 {

    public static void main(String[] args) throws IOException {

        int puertoRecepcion = 12341;

        KeyPair keys = null;
        try {
            keys = RsaUtil.generateKeyPair();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Mi nodo
        // La dirección en "logica" se obtiene de un hash a la clave publica
        Nodo nodo = new Nodo(1, "26.20.111.124", keys);
        // Poner el stake
        nodo.stake(30, "Type1");
        nodo.stake(40, "Type2");

        // Hilo para escuchar
        Entrada hiloEntrada = new Entrada(nodo, puertoRecepcion);
        hiloEntrada.start();

        // Buscar datos en la red
        nodo.buscarInfoRed();

        Scanner sc = new Scanner(System.in);
        sc.nextLine();

        // Hilo para validación PoS
        Validador hiloValidador = new Validador(nodo.getInfoRed(), nodo);
        hiloValidador.start();

        for (int i = 0; i < 700; i++) {
            int a = (int) (((Math.random()) * 2) + 1);
            if (a==1)
                nodo.sendMoneyTo(1.23, "26.143.218.218", "Type1");
            else
                nodo.sendMoneyTo(3.47, "26.37.38.157", "Type2");
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }

        sc.close();
    }
}
