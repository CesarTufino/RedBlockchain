package logicaDistribuida5.test;

import java.io.IOException;
import java.security.KeyPair;
import java.util.Scanner;

import logicaDistribuida5.conexion.Entrada;
import logicaDistribuida5.nodo.Nodo;
import logicaDistribuida5.nodo.Validador;
import logicaDistribuida5.utils.RsaUtil;

public class TestTipo2Nodo3 {

    public static void main(String[] args) throws IOException {
        // A donde se va a enviar
        int puertoRecepcion = 12343;

        KeyPair keys = null;
        try {
            keys = RsaUtil.generateKeyPair();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Mi nodo
        Nodo nodo = new Nodo(3, "26.143.218.218", keys);
        // Poner el stake
        nodo.stake(20, "Type1");
        nodo.stake(50, "Type2");

        // Hilo para escuchar
        Entrada serverThread = new Entrada(nodo, puertoRecepcion);
        serverThread.start();

        // Buscar datos en la red
        nodo.buscarInfoRed();

        Scanner sc = new Scanner(System.in);
        sc.nextLine();

        // Hilo para validación PoS
        Validador hiloValidador = new Validador(nodo.getInfoRed(), nodo);
        hiloValidador.start();

        nodo.sendMoneyTo(3.47, "26.20.111.124", "Type2");
        
        sc.close();
    }
}
