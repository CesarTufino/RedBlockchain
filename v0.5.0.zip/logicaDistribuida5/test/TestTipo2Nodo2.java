package logicaDistribuida5.test;

import java.io.IOException;
import java.security.KeyPair;
import java.util.Scanner;

import logicaDistribuida5.conexion.Entrada;
import logicaDistribuida5.nodo.Nodo;
import logicaDistribuida5.nodo.Validador;
import logicaDistribuida5.utils.RsaUtil;

public class TestTipo2Nodo2 {

    public static void main(String[] args) throws IOException {
        // A donde se va a enviar
        int puertoRecepcion = 12342;

        KeyPair keys = null;
        try {
            keys = RsaUtil.generateKeyPair();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Mi nodo
        Nodo nodo = new Nodo(2, "26.37.38.157", keys);
        // Poner el stake
        nodo.stake(25, "Type1");
        nodo.stake(45, "Type2");

        // Hilo para escuchar
        Entrada serverThread = new Entrada(nodo, puertoRecepcion);
        serverThread.start();

        // Buscar datos en la red
        nodo.buscarInfoRed();

        Scanner sc = new Scanner(System.in);
        sc.nextLine();

        // Hilo para validación PoS
        Validador hiloValidador = new Validador(nodo.getInfoRed(), nodo);
        hiloValidador.start();

        nodo.sendMoneyTo(1.23, "26.20.111.124", "Type1");
        
        sc.close();
    }
}
