package logicaDistribuida5.mensajes;

import java.io.Serializable;
import java.security.PublicKey;

public class InfoNodo implements Serializable{
    private String direccion;
    private PublicKey publicKey;
    private double stakeAmount1;
    private double stakeAmount2;
    private long stakeTime1;
    private long stakeTime2;
    
    
    public InfoNodo(String direccion, PublicKey publicKey, double stakeAmount1, double stakeAmount2, long stakeTime1, long stakeTime2) {
        this.direccion = direccion;
        this.publicKey = publicKey;
        this.stakeAmount1 = stakeAmount1;
        this.stakeAmount2 = stakeAmount2;
        this.stakeTime1 = stakeTime1;
        this.stakeTime2 = stakeTime2;
    }

    public PublicKey getPublicKey() {
        return publicKey;
    }

    public void setPublicKey(PublicKey publicKey) {
        this.publicKey = publicKey;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public double getStakeAmount1() {
        return stakeAmount1;
    }

    public void setStakeAmount1(double stakeAmount1) {
        this.stakeAmount1 = stakeAmount1;
    }

    public double getStakeAmount2() {
        return stakeAmount2;
    }

    public void setStakeAmount2(double stakeAmount2) {
        this.stakeAmount2 = stakeAmount2;
    }

    public long getStakeTime1() {
        return stakeTime1;
    }

    public void setStakeTime1(long stakeTime1) {
        this.stakeTime1 = stakeTime1;
    }

    public long getStakeTime2() {
        return stakeTime2;
    }

    public void setStakeTime2(long stakeTime2) {
        this.stakeTime2 = stakeTime2;
    }

}
