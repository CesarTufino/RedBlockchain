package logicaDistribuida5.nodo;

public class Validador extends Thread {

    private InfoRed infoRed = null;
    private Nodo miNodo = null;
    private final String ANSI_GREEN = "\u001B[32m";
    private final String ANSI_BLUE = "\u001B[34m";
    private final String ANSI_RESET = "\u001B[0m";

    public Validador(InfoRed infoRed, Nodo miNodo) {
        this.infoRed = infoRed;
        this.miNodo = miNodo;
    }

    public void validar() {
        while (true) {
            long start = System.currentTimeMillis();
            String[] seleccionados = determinarSeleccionadosPoS();

            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if (seleccionados[0].equals(miNodo.getAddress())) {
                System.out.println(ANSI_GREEN + "/////////////// Se crea el Bloque Tipo 1 ////////////" + ANSI_RESET);
                miNodo.forgeBlock("Type1");
            }

            if (seleccionados[1].equals(miNodo.getAddress())) {
                System.out.println(ANSI_GREEN + "/////////////// Se crea el Bloque Tipo 2 ////////////" + ANSI_RESET);
                miNodo.forgeBlock("Type2");
            }

            while (true) {
                long end = System.currentTimeMillis();
                if (end - start > 10000) { // 10 segundos
                    break;
                }
            }
        }
    }

    private String[] determinarSeleccionadosPoS() {
        System.out.println(ANSI_BLUE + "/////////////// Seleccionando nodos //////////" + ANSI_RESET);
        return infoRed.getMasNodosSeleccionados();
    }

    @Override
    public void run() {
        long tiempoParaIniciar = 10000 - (infoRed.getTiempoTranscurrido() % 10000);
        System.out.println();
        try {
            Thread.sleep(tiempoParaIniciar);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        validar();
    }

}
