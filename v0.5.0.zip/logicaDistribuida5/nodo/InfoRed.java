package logicaDistribuida5.nodo;

import java.io.Serializable;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import logicaDistribuida5.mensajes.InfoNodo;
import logicaDistribuida5.blockchain.Block;
import logicaDistribuida5.blockchain.Blockchain;

public class InfoRed implements Serializable {

    /**
     * Número de bloques del primer blockchain lógico.
     **/
    public List<Integer> NB_OF_BLOCK_OF_TYPE1_CREATED = new ArrayList<>();
    /**
     * Número de bloques del segundo blockchain lógico.
     */
    public List<Integer> NB_OF_BLOCK_OF_TYPE2_CREATED = new ArrayList<>();
    /**
     * Lista de tiempos (lapso que se demora en encontrar el bloque previo de un
     * blockchain lógico.)
     */
    public List<Double> ST = new ArrayList<>();
    /**
     * Lista de los nodos elegidos para la creación de bloques.
     */
    public List<Integer> ELECTED = new ArrayList<>();
    /**
     * Intercambios de dinero del primer blockchain lógico.
     */
    public List<Double> EXCHANGE_MONEY1 = new ArrayList<>();
    /**
     * Intercambios de dinero del segundo blockchain lógico.
     */
    public List<Double> EXCHANGE_MONEY2 = new ArrayList<>();
    /**
     * Identificador del primer blockchain lógico.
     */
    public final String TYPE1 = "Type1";
    /**
     * Identificador del segundo blockchain lógico.
     */
    public final String TYPE2 = "Type2";
    /**
     * Tabla de mapeo de NodeAddress y PublicKey para verificar firmas.
     */
    private final Map<String, PublicKey> keyTable = new HashMap<>();
    /**
     * Número de transacciones de cada blockchain lógico.
     */
    private final Map<String, Integer> nbTransParType = new HashMap<>();
    private Map<String, Double> mapStakeAmount1 = new HashMap<>();
    private Map<String, Double> mapStakeAmount2 = new HashMap<>();
    private Map<String, Long> mapStakeTime1 = new HashMap<>();
    private Map<String, Long> mapStakeTime2 = new HashMap<>();
    private long relojInterno;

    private Blockchain blockchain;

    public InfoRed() {
        this.blockchain = new Blockchain();
        nbTransParType.put(TYPE1, 0);
        nbTransParType.put(TYPE2, 0);
        NB_OF_BLOCK_OF_TYPE1_CREATED.add(1);
        NB_OF_BLOCK_OF_TYPE2_CREATED.add(1);
        EXCHANGE_MONEY1.add(0.);
        EXCHANGE_MONEY2.add(0.);
        relojInterno = System.currentTimeMillis();
    }

    public long getTiempoTranscurrido() {
        return System.currentTimeMillis() - relojInterno;
    }

    public void addNode(InfoNodo infoNodo) {
        String direccion = infoNodo.getDireccion();

        mapStakeAmount1.put(direccion, infoNodo.getStakeAmount1());
        mapStakeAmount2.put(direccion, infoNodo.getStakeAmount2());
        mapStakeTime1.put(direccion, infoNodo.getStakeTime1());
        mapStakeTime2.put(direccion, infoNodo.getStakeTime2());
        try {
            keyTable.put(direccion, infoNodo.getPublicKey());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void printStats() {
        System.out.println("\n////////////////////////////////////////////");
        System.out.println("ST=" + ST);
        System.out.println("NBT1=" + NB_OF_BLOCK_OF_TYPE1_CREATED);
        System.out.println("NBT2=" + NB_OF_BLOCK_OF_TYPE2_CREATED);
        System.out.println("WTT1=" + blockchain.getWTT1());
        System.out.println("WTT2=" + blockchain.getWTT2());
        System.out.println("Type_1_currency_exchanged=" + EXCHANGE_MONEY1);
        System.out.println("Type_2_currency_exchanged=" + EXCHANGE_MONEY2);
        System.out.println("////////////////////////////////////////////\n");
    }

    public PublicKey getPkWithAddress(String address) {
        return keyTable.get(address);
    }

    public Map<String, Integer> getNbTransParType() {
        return nbTransParType;
    }

    public void setNbTransParType(String type, int nb) {
        this.nbTransParType.put(type, nb);
    }

    public String[] getMasNodosSeleccionados() {
        String[] direccionesSeleccionadas = new String[2];
        Map<String, Double> probabilidades1 = new HashMap<>();
        Map<String, Double> probabilidades2 = new HashMap<>();
        double suma1 = 0, suma2 = 0, sumaAcumulada1 = 0, sumaAcumulada2 = 0, numeroPseudoaleatorio1 = 0,
                numeroPseudoaleatorio2 = 0;
        long semilla1 = 0, semilla2 = 0;
        Random rnd;

        for (String direccion : mapStakeAmount1.keySet()) {
            suma1 += mapStakeAmount1.get(direccion);
            semilla1 += mapStakeAmount1.get(direccion) * mapStakeTime1.get(direccion);
        }
        rnd = new Random(semilla1);
        numeroPseudoaleatorio1 = rnd.nextInt(101);
        System.out.println("Número pseudoaleatorio 1: " + numeroPseudoaleatorio1);
        for (String direccion : mapStakeAmount1.keySet()) {
            probabilidades1.put(direccion, (mapStakeAmount1.get(direccion) / suma1) * 100);
        }
        for (String direccion : probabilidades1.keySet()) {
            sumaAcumulada1 += probabilidades1.get(direccion);
            if (numeroPseudoaleatorio1 <= sumaAcumulada1) {
                direccionesSeleccionadas[0] = direccion;
                mapStakeTime1.put(direccion, mapStakeTime1.get(direccion) + 10000);
                break;
            }
        }

        for (String direccion : mapStakeAmount2.keySet()) {
            if (!direccion.equals(direccionesSeleccionadas[0])) {
                suma2 += mapStakeAmount2.get(direccion);
                semilla2 += mapStakeAmount2.get(direccion) * mapStakeTime2.get(direccion);
            }
        }
        rnd = new Random(semilla2);
        numeroPseudoaleatorio2 = rnd.nextInt(101);
        System.out.println("Número pseudoaleatorio 2: " + numeroPseudoaleatorio2);

        for (String direccion : mapStakeAmount2.keySet()) {
            if (!direccion.equals(direccionesSeleccionadas[0])) {
                probabilidades2.put(direccion, (mapStakeAmount2.get(direccion) / suma2) * 100);
            }
        }
        for (String direccion : probabilidades2.keySet()) {
            sumaAcumulada2 += probabilidades2.get(direccion);
            if (numeroPseudoaleatorio2 <= sumaAcumulada2) {
                direccionesSeleccionadas[1] = direccion;
                mapStakeTime2.put(direccion, mapStakeTime2.get(direccion) + 10000);
                break;
            }
        }
        System.out.println(
                "Nodos seleccionados: 1:" + direccionesSeleccionadas[0] + ", 2:" + direccionesSeleccionadas[1]);
        return direccionesSeleccionadas;
    }

    public Blockchain getBlockchain() {
        return blockchain;
    }

    public void addBlock(Block b) {
        blockchain.addBlock(b);
    }

    public Map<String, Long> getMapStakeTime1() {
        return mapStakeTime1;
    }

    public Map<String, Long> getMapStakeTime2() {
        return mapStakeTime2;
    }

}