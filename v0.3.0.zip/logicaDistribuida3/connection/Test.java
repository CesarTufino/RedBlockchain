package logicaDistribuida3.connection;

import java.io.IOException;
import java.security.KeyPair;

import logicaDistribuida3.nodo.Nodo;
import logicaDistribuida3.utils.RsaUtil;

public class Test {

    public static void main(String[] args) throws IOException {

        int puertoRecepcion = 12346;

        KeyPair keys = null;
        try {
            keys = RsaUtil.generateKeyPair();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Mi nodo
        // La dirección en "logica" se obtiene de un hash a la clave publica
        Nodo nodo = new Nodo(1, "26.20.111.125", keys);
        // Poner el stake
        nodo.stake(20, "Type1");
        nodo.stake(10, "Type2");
        nodo.addInvestorType(nodo.getNodeAddress(), nodo.getStakeAmount1(), "Type1"); // ln1.getNodeAddress(),
                                                                                      // ln1.getStakeAmount1(), TYPE1
        nodo.addInvestorType(nodo.getNodeAddress(), nodo.getStakeAmount1(), "Type2");

        // Hilo para escuchar
        Entrada serverThread = new Entrada(nodo, puertoRecepcion);
        serverThread.start();

        nodo.buscarInfoRed();

        //long start = System.nanoTime();

        for (int i = 0; i < 20; i++) {
            int a = (int) (((Math.random()) * 2) + 1);
            double p_t1;
            if (a == 1)
                p_t1 = 0.85;
            else {
                p_t1 = 0.30;
            }
            for (int j = 0; j < 2 * (Math.random() * 3) + 1; j++) {
                double b = Math.random();
                if (b < p_t1)
                    nodo.sendMoneyTo(1.23, "26.37.38.157", "Type1");
                else
                    nodo.sendMoneyTo(3.47, "26.143.218.218", "Type2");
            }
        }

        // El tiempo debe tomarse al recibir todos la información, no al mandarla
        //long end = System.nanoTime();
        //System.out.println("\n\n\n\n\n");
        //System.out.println("/////////////Tiempo total"+ (end - start));
        //System.out.println("\n\n\n\n\n");
    }
}
